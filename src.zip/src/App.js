import './App.css';
import React, {Component} from 'react'
import Subject from "./component/Subject"
import TOC from "./component/TOC"
import Content from "./component/Content"
import Control from "./component/Control"

class App extends Component{

  constructor(props){
    super(props);

    this.state ={
       
      mode: '1',
      selectec_id:1,
      subject:{title : 'SE3910', sub: 'Software Engineering'}, 
      welcome:{title : 'Welcome', desc : 'Hello ReactJS !!!'},

      contents:[
        {id:1, title:"SpringBoot", desc:"MVC framework"},
        {id:2, title:"ReactJS", desc:"front-end programming"},
        {id:3, title:"Agile", desc:"SCRUM, LEAN, KANBAN"}
      ]
    }
  }

  render(){

    var _title, _desc = null;
    if(this.state.mode === '1'){
      _title = this.state.welcome.title;
      _desc = this.state.welcome.desc;
    }else if(this.state.mode === '2'){

      var i = 0;
      while(i < this.state.contents.length){
        var data = this.state.contents[i];
        
        if(data.id === this.state.selected_id){
          _title = data.title;
          _desc = data.desc;
          break;
        }
        
        i = i + 1;
      }

    }


    return(
      <div className="App">
        <Subject title = {this.state.subject.title} 
        sub={this.state.subject.sub}
        onChangePage = {function(){

          this.setState({
            mode:'2'
          }); 

        }.bind(this)}
      
        ></Subject>
        

        {/* <header>
          <h1><a href="/" onClick={function(e){

            e.preventDefault();
            //this.state.mode = '2';
            this.setState({
              mode:'2'
            }); 
            
          }.bind(this)}
          >  
          {this.state.subject.title}</a></h1>
          {this.state.subject.sub}
        </header>     */}


        <TOC onChangePage ={function(id){

          this.setState({
            mode:'2',
            selected_id:Number(id)
          }); 
        
        }.bind(this)} data={this.state.contents}>

        </TOC>

        <Control></Control>  


        <Content title={_title} desc = {_desc}></Content>
      </div>
    );
  }
}



export default App;
